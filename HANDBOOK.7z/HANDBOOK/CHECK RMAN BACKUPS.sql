col STATUS format a10
col hrs format 999.99

select SESSION_KEY, INPUT_TYPE, STATUS,
to_char(START_TIME,'mm/dd/yy hh24:mi') start_time,
to_char(END_TIME,'mm/dd/yy hh24:mi') end_time,
elapsed_seconds/3600 hrs from V$RMAN_BACKUP_JOB_DETAILS
where to_char(END_TIME,'mm/dd/yy hh24:mi') > to_char(sysdate - 1.3,'mm/dd/yy hh24:mi')
order by session_key;

select name from v$database;