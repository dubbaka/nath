#!usr/bin/env bash

#Author: Ranganath Reddy Dubbaka
#Date: 16-July-2023

# Set Profile Environment.
. /home/oracle/.bash_profile

# Set SCRIPT_DIR environment variable and create directory if not exist.
export SCRIPT_DIR=/home/oracle/nath/scripts
mkdir -p $SCRIPT_DIR

# Assiging hostname value.
host=$(hostname)

# Assiging first parameter value after removing single codes.
last_node_sid=$(echo $1 | sed "s/'//g")
#echo $last_node_sid

# Get sid value from the environment, after validation just saving database names into it.
sid_values=$(ps -ef | grep pmon | grep -v grep | grep -v + | awk '{ print $8 }' | cut -d '_' -f3 | sed 's/.$//')

# Setting db counter to Zero.
db_count=0

# Loop all database names that are saved in sid_values.
for sid in $sid_values
do
	# Check if the database details are already captured, this condition is to remove duplicates.
	if echo "${last_node_sid[@]}" | grep -qv "$sid";
	then

		# Set database environment.
		source $HOME/$sid.env > /dev/null 2>&1
		# Incrementing the db counter.
		db_count=$((db_count+1))

		# Checking if this DB is a container database.
		cdb=$($ORACLE_HOME/bin/sqlplus -S /nolog << EOF
connect / as sysdba
whenever sqlerror exit sql.sqlcode
set echo off
set feedback off
set heading off
set pages 0
select cdb from v\$database;
exit;
EOF
)

		# Get the database version details.
		version=$($ORACLE_HOME/bin/sqlplus -S /nolog << EOF
connect / as sysdba
whenever sqlerror exit sql.sqlcode
set echo off
set feedback off
set heading off
set pages 0
select VERSION from v\$instance;
exit;
EOF
)

		# Get major version number which is before first decimal. 
		version=$(echo $version | cut -d '.' -f1)

		# Checking for database version equal to 19.
		if [[ $version -eq 19 ]]
		then
		
			# Checking if the DB is a container database. 
			if [[ $cdb = "YES" ]]
			then

				$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY p.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION from v\$instance) as VERSION,
d.name as DATABASE,
p.name as PDB_NAME,
p.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d, v\$pdbs p
where p.name NOT IN ('PDB\$SEED') and p.name NOT LIKE '%PDB1'
;
exit;
EOF

			else

				$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY d.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION from v\$instance) as VERSION,
d.name DATABASE,
'NON-CDB' as PDB_NAME,
d.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d
;
exit;
EOF

			fi

		else

			if [[ $cdb = "YES" ]]
			then

				$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY p.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION from v\$instance) as VERSION,
d.name as DATABASE,
p.name as PDB_NAME,
p.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d, v\$pdbs p
where p.name NOT IN ('PDB\$SEED') and p.name NOT LIKE '%PDB1'
;
exit;
EOF

			else

				$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY d.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION from v\$instance) as VERSION,
d.name DATABASE,
'NON-CDB' as PDB_NAME,
d.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d
;
exit;
EOF

			fi

		fi

	fi

done

node1=$2

# Saving all sid values to a file on cluster node1
echo "'$last_node_sid $sid_values'" | ssh $node1 -q 'cat > /tmp/last_node_sid_values.txt'

#End of Script
