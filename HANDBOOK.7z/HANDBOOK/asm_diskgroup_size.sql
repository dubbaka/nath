SET ECHO        OFF
 SET FEEDBACK    6
 SET HEADING     ON
 SET LINESIZE    180
 SET PAGESIZE    50000
 SET TERMOUT     ON
 SET TIMING      OFF
 SET TRIMOUT     ON
 SET TRIMSPOOL   ON
 SET VERIFY      OFF
 CLEAR COLUMNS
 CLEAR BREAKS
 CLEAR COMPUTES
 COLUMN group_name             FORMAT a25           HEAD 'Disk Group|Name'
 COLUMN state                  FORMAT a11           HEAD 'State'
 COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (GB)'
 COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (GB)'
 COLUMN free_mb                FORMAT 999,999,999   HEAD 'Free Size (GB)'
 COLUMN pct_used               FORMAT 999.99        HEAD '% Used'
 BREAK ON report ON disk_group_name SKIP 1
 COMPUTE sum LABEL "Grand Total: " OF total_mb used_mb free_mb ON report
 SELECT
     name                                     group_name
   , state                                    state
   , total_mb/1024                            total_mb
   , (total_mb - free_mb)/1024                used_mb
   , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
   , free_mb/1024                             free_mb
 FROM
     v$asm_diskgroup
 WHERE
     total_mb != 0
 ORDER BY
     Name
 /
