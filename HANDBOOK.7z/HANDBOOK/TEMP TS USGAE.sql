--check TEMP tablespace usage

select name from v$database;
select tablespace_name,file_name,bytes/1024/1024, maxbytes/1024/1024 from dba_temp_files;

--select tablespace_name, ' %free='|| round(sum(free_blocks) / sum(total_blocks) * 100 ,0) from gv$sort_segment group by tablespace_name;

SELECT A.tablespace_name tablespace, D.gb_total,
    SUM (A.used_blocks * D.block_size) / 1024 / 1024 /1024 gb_used,
    D.gb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 /1024  gb_free,
    round(sum(A.free_blocks) / sum(A.total_blocks) * 100 ,2) percentage_free
   FROM v$sort_segment A,
    (
   SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 /1024 gb_total
    FROM v$tablespace B, v$tempfile C
     WHERE B.ts#= C.ts#
      GROUP BY B.name, C.block_size) D
    WHERE A.tablespace_name = D.name
    GROUP by A.tablespace_name, D.gb_total;
    
