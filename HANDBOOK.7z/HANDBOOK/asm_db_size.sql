set echo off feedback off heading on
set lines 400 linesize 132 feed 200 pagesize 75 trimspool on pause off tab off
column DATABASE format a25
--col "GB" format 99,999.9
SELECT
disk_group_name
,SUBSTR(alias_path,2,INSTR(alias_path,'/',1,2)-2) Database
,ROUND(SUM(alloc_bytes)/1024/1024/1024,1) "Size (GB)"
,ROUND(SUM(alloc_bytes)/1024/1024,1) "Size (MB)"
FROM
(SELECT
SYS_CONNECT_BY_PATH(alias_name, '/') alias_path
,alloc_bytes, disk_group_name
FROM
(SELECT
g.name disk_group_name
, a.parent_index pindex
, a.name alias_name
, a.reference_index rindex
, f.space alloc_bytes
, f.type type
FROM
v$asm_file f RIGHT OUTER JOIN v$asm_alias a
USING (group_number, file_number)
JOIN v$asm_diskgroup g
USING (group_number)
)
WHERE type IS NOT NULL
START WITH (MOD(pindex, POWER(2, 24))) = 0
CONNECT BY PRIOR rindex = pindex
)
GROUP BY disk_group_name, SUBSTR(alias_path,2,INSTR(alias_path,'/',1,2)-2)
ORDER BY 1;
