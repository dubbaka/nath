#!usr/bin/env bash

#Author: Ranganath Reddy Dubbaka
#Date: 16-July-2023

. /home/oracle/.bash_profile
export SCRIPT_DIR=/home/oracle/nath/scripts
mkdir -p $SCRIPT_DIR
host=$(hostname)
last_node_sid=$(echo $1 | sed "s/'//g")
#echo $last_node_sid
sid_values=$(ps -ef | grep pmon | grep -v grep | grep -v + | awk '{ print $8 }' | cut -d '_' -f3 | sed 's/.$//')
db_count=0

for sid in $sid_values
do

if echo "${last_node_sid[@]}" | grep -qv "$sid";
then

source $HOME/$sid.env > /dev/null 2>&1
db_count=$((db_count+1))
cdb=$($ORACLE_HOME/bin/sqlplus -S /nolog << EOF
connect / as sysdba
whenever sqlerror exit sql.sqlcode
set echo off
set feedback off
set heading off
set pages 0
select cdb from v\$database;
exit;
EOF
)

if [[ $cdb = "YES" ]]
then

$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY p.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION_FULL from v\$instance) as VERSION,
d.name as DATABASE,
p.name as PDB_NAME,
p.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d, v\$pdbs p
where p.name NOT IN ('PDB\$SEED') and p.name NOT LIKE '%PDB1'
;
exit;
EOF

else

$ORACLE_HOME/bin/sqlplus -S /nolog <<EOF
connect / as sysdba
set feedback off
set head off
set linesize 1000
col HOSTNAME for a12;
col DATABASE for a12;
col PDB_NAME for a12;
col OPEN_MODE for a12;
col VERSION for a12;
select
ROW_NUMBER() OVER (ORDER BY d.name) AS PDB_COUNT,
(SELECT SUBSTR(i.HOST_NAME ,1,v.pos-1) from v\$instance i, (SELECT INSTR(HOST_NAME,'.',1,1) as pos from v\$instance) v) as HOSTNAME,
(select VERSION_FULL from v\$instance) as VERSION,
d.name DATABASE,
'NON-CDB' as PDB_NAME,
d.open_mode,
(select count(*) from gv\$instance) as INSTANCE_COUNT
from v\$database d
;
exit;
EOF

fi

fi

done

node1=$2
echo "'$sid_values'" > /tmp/last_node_sid_values.txt
scp -q /tmp/last_node_sid_values.txt ${node1}:/tmp/last_node_sid_values.txt

#End of Script
