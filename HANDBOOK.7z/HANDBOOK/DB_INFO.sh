#!usr/bin/env bash

#Author: Ranganath Reddy Dubbaka
#Date: 16-July-2023

last_node_sid="'ONE TWO'"
export last_node_sid
echo $last_node_sid > /tmp/last_node_sid_values.txt

node1=$(echo $(hostname) | cut -d '.' -f1)
node_s1=$(echo $node1 | cut -c 1-3)
node_s2=$(echo $node1 | cut -c 4-6)
node_s3=$(echo $node1 | cut -c 7-10)
node_num=${node_s2}

echo "-------------------------------------------------------------------------------------------"
echo "PDB_COUNT    HOSTNAME   VERSION      DATABASE     PDB_NAME     OPEN_MODE    INSTANCES"
echo "---------- ------------ ------------ ------------ ------------ ------------ --------------"


node1=${node_s1}${node_num}${node_s3}
ssh $node1 -q 'bash -s' < /home/oracle/nath/scripts/cluster_db_info.sh $last_node_sid $node1
last_node_sid=$(cat /tmp/last_node_sid_values.txt)

node_num=$((node_num+1))
node2=${node_s1}${node_num}${node_s3}
ssh $node2 -q 'bash -s' < /home/oracle/nath/scripts/cluster_db_info.sh $last_node_sid $node1
last_node_sid=$(cat /tmp/last_node_sid_values.txt)

node_num=$((node_num+1))
node3=${node_s1}${node_num}${node_s3}
ssh $node3 -q 'bash -s' < /home/oracle/nath/scripts/cluster_db_info.sh $last_node_sid $node1
last_node_sid=$(cat /tmp/last_node_sid_values.txt)

node_num=$((node_num+1))
node4=${node_s1}${node_num}${node_s3}
ssh $node4 -q 'bash -s' < /home/oracle/nath/scripts/cluster_db_info.sh $last_node_sid $node1
last_node_sid=$(cat /tmp/last_node_sid_values.txt)

echo "-------------------------------------------------------------------------------------------"
