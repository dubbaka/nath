#!/bin/sh

######################################################
# This script shows the space utilization in oracle database
#
######################################################
# Set the Oracle environment variables
. /home/oracle/PRETMCON.env
PATH=$PATH:$ORACLE_HOME/bin:/bin/:/usr/bin:/usr/local/bin:/usr/sbin:.; export PATH
#MAILING_LIST1="sbommar@templeton.com,svandan@templeton.com";
#MAILING_LIST1="sbommar@templeton.com";
ORACLE_SID=$1 ; export ORACLE_SID
CONT_NAME=$2 ; export CONT_NAME
USERNAME=$3 ; export USERNAME
ORACLE_BASE=/u02/app/oracle; export ORACLE_BASE;

sqlplus -s "/ as sysdba" << EOF
SET PAGESIZE 0
--SET LINESIZE 200
SET FEEDBACK OFF
SET HEADING OFF
--SET TRIMSPOOL ON
--SET TAB ON
SET COLSEP ','
SET MARKUP CSV ON
alter session set container= $CONT_NAME;
alter session set current_schema= $USERNAME;
SPOOL TASK1732849_REPORT_YEAR2017.csv
-- Your SQL query goes here
@sql_2017.sql
SPOOL OFF
EXIT
EOF


USAGE:
sh sqlcsv_2019.sh PRETMCON1 TAPRD TKCSOWNER > /dev/null 2>&1 &


expdp username/password@database QUERY=\"select * from table\" DIRECTORY=data_pump_dir DUMPFILE=output.dmp LOGFILE=output.log

