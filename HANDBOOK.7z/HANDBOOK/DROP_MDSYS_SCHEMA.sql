-- Steps for Manual De-installation of Oracle Spatial/Locator (Doc ID 179472.1)

select owner,index_name from dba_indexes
where ityp_name = 'SPATIAL_INDEX';

select owner, table_name, column_name
from dba_tab_columns
where data_type = 'SDO_GEOMETRY'
and owner != 'MDSYS'
order by 1,2,3;

select 'drop index ' || owner || '.' || index_name ||';'
from dba_indexes where ityp_name = 'SPATIAL_INDEX';

select owner, table_name, column_name
from dba_tab_columns
where data_type = 'SDO_GEOMETRY'
and owner != 'MDSYS'
order by 1,2,3;

select owner, table_name, column_name
from dba_tab_columns
where data_type = 'SDO_GEOMETRY'
and owner != 'MDSYS'
order by 1,2,3;

select owner, table_name, column_name
from dba_tab_columns
where data_type = 'SDO_GEOMETRY'
and owner != 'MDSYS'
order by 1,2,3;

select * from dba_users where username='MDSYS';

drop user MDSYS cascade;