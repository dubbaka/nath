set feedback OFF
set heading OFF
spool execute_audit_items_missing.sql
select 'AUDIT '||name||' By Access;'
from system_privilege_map A
where not exists ( select 1
                       from (select audit_option "AUDIT_ACTION" from dba_stmt_audit_opts
                                     union
                                     select PRIVILEGE "AUDIT_ACTION" from dba_priv_audit_opts) B
                        where A.NAME = B.AUDIT_ACTION)
union
select 'AUDIT '||name||' By Access;'
from stmt_audit_option_map A
where not exists ( select 1
                       from dba_stmt_audit_opts b
                       where b.user_name is null
                       and b.AUDIT_OPTION = A.NAME)
and a.NAME in (
'CLUSTER','CONTEXT','DATABASE LINK',
'DIMENSION','DIRECTORY','EXECUTE LIBRARY','GRANT DIRECTORY','GRANT PROCEDURE','GRANT SEQUENCE','GRANT TABLE','GRANT TYPE',
'INDEX','MATERIALIZED VIEW','PROCEDURE','PROFILE','PUBLIC DATABASE LINK','PUBLIC SYNONYM','ROLE','ROLLBACK SEGMENT',
'SEQUENCE','SESSION','SYNONYM','SYSTEM AUDIT','SYSTEM GRANT','TABLE','TABLESPACE','TRIGGER','TYPE','USER','VIEW'
)
Order by 1;
spool off