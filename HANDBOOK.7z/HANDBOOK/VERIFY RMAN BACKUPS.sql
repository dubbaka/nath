-- STEP 1:  To find the status of the jobs:
set lines 300
 col STATUS format a22
 col hrs format 999.99
 select
 SESSION_KEY, SESSION_RECID, SESSION_STAMP,INPUT_TYPE, STATUS,
 to_char(START_TIME,'dd/mm/yy hh24:mi') start_time,
 to_char(END_TIME,'dd/mm/yy hh24:mi')   end_time,
 elapsed_seconds/3600                   hrs
 from V$RMAN_BACKUP_JOB_DETAILS
 where to_char(START_TIME,'dd/mm/yy hh24:mi') > to_char(sysdate - 1,'dd/mm/yy hh24:mi')
 order by session_key
 desc;


--STEP 2:  Check the % completed and more detailed information:

SELECT SID, SERIAL#, CONTEXT, SOFAR, TOTALWORK,
 ROUND (SOFAR/TOTALWORK*100, 2) "% COMPLETE"
 FROM V$SESSION_LONGOPS
 WHERE OPNAME LIKE 'RMAN%' AND OPNAME NOT LIKE '%aggregate%'
 AND TOTALWORK! = 0 AND SOFAR <> TOTALWORK;


--STEP 3: Check the logs or output of the running RMAN jobs 
set lines 200
 set pages 1000
 select output from GV$RMAN_OUTPUT
 where session_recid = &SESSION_RECID
 and session_stamp = &SESSION_STAMP
 order by recid;

--NOTE: Please enter  SESSION_RECID  and  SESSION_STAMP  from the 1st query mentioned in step 1.
